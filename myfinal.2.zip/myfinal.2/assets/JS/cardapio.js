let pedido = []; // Array para armazenar os itens do pedido

// Função para adicionar um produto ao pedido
function addProduct(productName, productPrice) {
    const item = { nome: productName, preco: productPrice };
    pedido.push(item);
    updateCart();
}

// Função para remover um produto do pedido
function removeProduct(product) {
    const quantityElement = document.getElementById(`quantity-${product}`);
    let quantity = parseInt(quantityElement.textContent);
    if (quantity > 0) {
        quantityElement.textContent = --quantity;
    }
    updateCart();
}

// Função para mostrar os itens de uma categoria
function showCategory(category) {
    const dishesContainer = document.getElementById('dishes');
    dishesContainer.innerHTML = ''; // Limpa os pratos anteriores

    // Adiciona os pratos da categoria selecionada
    switch (category) {
        case 'bebidas':
            dishesContainer.innerHTML = `
                <div class="dish">
                    <p>Suco de Laranja - R$ 5,99</p>
                    <div class="buttons">
                        <button onclick="removeProduct('suco_laranja')">-</button>
                        <span id="quantity-suco_laranja">0</span>
                        <button onclick="addProduct('Suco de Laranja', 5.99)">+</button>
                        <button onclick="addToCart('Suco de Laranja', 5.99)">Adicionar ao Pedido</button>
                    </div>
                </div>
                <div class="dish">
                    <p>Refrigerante - R$ 8,00</p>
                    <div class="buttons">
                        <button onclick="removeProduct('refrigerante')">-</button>
                        <span id="quantity-refrigerante">0</span>
                        <button onclick="addProduct('Refrigerante', 8.00)">+</button>
                        <button onclick="addToCart('Refrigerante', 8.00)">Adicionar ao Pedido</button>
                    </div>
                </div>
                <div class="dish">
                    <p>Água - R$ 3,50</p>
                    <div class="buttons">
                        <button onclick="removeProduct('agua')">-</button>
                        <span id="quantity-agua">0</span>
                        <button onclick="addProduct('Água', 3.50)">+</button>
                        <button onclick="addToCart('Água', 3.50)">Adicionar ao Pedido</button>
                    </div>
                </div>
            `;
            break;
        case 'pizza':
            dishesContainer.innerHTML = `
                <div class="dish">
                    <p>Calabresa - R$ 30,00</p>
                    <div class="buttons">
                        <button onclick="removeProduct('calabresa')">-</button>
                        <span id="quantity-calabresa">0</span>
                        <button onclick="addProduct('Calabresa', 30.00)">+</button>
                        <button onclick="addToCart('Calabresa', 30.00)">Adicionar ao Pedido</button>
                    </div>
                </div>
                <div class="dish">
                    <p>Quatro Queijos - R$ 35,00</p>
                    <div class="buttons">
                        <button onclick="removeProduct('quatro_queijos')">-</button>
                        <span id="quantity-quatro_queijos">0</span>
                        <button onclick="addProduct('Quatro Queijos', 35.00)">+</button>
                        <button onclick="addToCart('Quatro Queijos', 35.00)">Adicionar ao Pedido</button>
                    </div>
                </div>
                <div class="dish">
                    <p>Margherita - R$ 25,00</p>
                    <div class="buttons">
                        <button onclick="removeProduct('margherita')">-</button>
                        <span id="quantity-margherita">0</span>
                        <button onclick="addProduct('Margherita', 25.00)">+</button>
                        <button onclick="addToCart('Margherita', 25.00)">Adicionar ao Pedido</button>
                    </div>
                </div>
            `;
            break;
        case 'acompanhamentos':
            dishesContainer.innerHTML = `
                <div class="dish">
                    <p>Batata Frita - R$ 15,00</p>
                    <div class="buttons">
                        <button onclick="removeProduct('batata_frita')">-</button>
                        <span id="quantity-batata_frita">0</span>
                        <button onclick="addProduct('Batata Frita', 15.00)">+</button>
                        <button onclick="addToCart('Batata Frita', 15.00)">Adicionar ao Pedido</button>
                    </div>
                </div>
                <div class="dish">
                    <p>Arroz Branco - R$ 10,00</p>
                    <div class="buttons">
                        <button onclick="removeProduct('arroz_branco')">-</button>
                        <span id="quantity-arroz_branco">0</span>
                        <button onclick="addProduct('Arroz Branco', 10.00)">+</button>
                        <button onclick="addToCart('Arroz Branco', 10.00)">Adicionar ao Pedido</button>
                    </div>
                </div>
            `;
            break;
    
    case 'sobremesas':
    dishesContainer.innerHTML = `
        <div class="dish">
            <p>Torta de Limão - R$ 12,00</p>
            <div class="buttons">
                <button onclick="removeProduct('torta_limao')">-</button>
                <span id="quantity-torta_limao">0</span>
                <button onclick="addProduct('Torta de Limão', 12.00)">+</button>
                <button onclick="addToCart('Torta de Limão', 12.00)">Adicionar ao Pedido</button>
            </div>
        </div>
        <div class="dish">
            <p>Pudim de Leite - R$ 10,00</p>
            <div class="buttons">
                <button onclick="removeProduct('pudim_leite')">-</button>
                <span id="quantity-pudim_leite">0</span>
                <button onclick="addProduct('Pudim de Leite', 10.00)">+</button>
                <button onclick="addToCart('Pudim de Leite', 10.00)">Adicionar ao Pedido</button>
            </div>
        </div>
        <div class="dish">
            <p>Sorvete de Chocolate - R$ 8,00</p>
            <div class="buttons">
                <button onclick="removeProduct('sorvete_chocolate')">-</button>
                <span id="quantity-sorvete_chocolate">0</span>
                <button onclick="addProduct('Sorvete de Chocolate', 8.00)">+</button>
                <button onclick="addToCart('Sorvete de Chocolate', 8.00)">Adicionar ao Pedido</button>
            </div>
        </div>
    `;
    break;
    }
}

// Função para atualizar o carrinho
function updateCart() {
    // Implemente a lógica para atualizar o carrinho aqui
}

// Função para adicionar ao carrinho
function addToCart(productName, productPrice) {
    // Implemente a lógica para adicionar ao carrinho aqui
}
