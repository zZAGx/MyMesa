<?php
// Incluir o arquivo de conexão
include 'conexao.php';

// Verificar a conexão
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

// Exibir mensagem de sucesso ou erro
$message = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = $_POST['username'];
    $cpf = $_POST['password'];
    
    // Verificar se os campos estão preenchidos
    if (!empty($nome)) {
        // Prepara a declaração SQL
        $stmt = $conn->prepare("INSERT INTO pedidos (nome, cpf) VALUES (?, ?)");
        
        if ($stmt) {
            $stmt->bind_param("ss", $nome, $cpf);
            
            if ($stmt->execute()) {
                $message = "Nome salvo com sucesso!";
                header("Location: cardapio.php");
                exit();
            } else {
                $message = "Erro na execução: " . $stmt->error;
            }
            
            $stmt->close();
        } else {
            $message = "Erro na preparação da declaração: " . $conn->error;
        }
    } else {
        $message = "Por favor, preencha o nome.";
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="/assets/CSS/styles.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <style>
        .montserrat {
            font-family: "Montserrat", sans-serif;
            font-optical-sizing: auto;
            font-weight: 900;
            font-style: normal;
            letter-spacing: 2px;
        }
        body {
            font-family: "Montserrat", sans-serif;
            margin: 0;
            padding: 0;
            border-radius: 10px;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 900;
            letter-spacing: 2px;
        }
        header {
            background-color: #FF6666;
            color: #fff;
            padding: 20px;
            text-align: center;
            width: 100%;
            position: absolute;
            top: 0;
        }
        header h1 {
            font-size: 36px;
            font-weight: 900;
            letter-spacing: 3px;
        }
        .login-container {
            width: 100vw;
            height: 100vh;
            padding: 40px;
            background-color: #f9f9f9;
            border-radius: 0;
            box-sizing: border-box;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            font-weight: 900;
            letter-spacing: 2px;
        }
        input[type="text"],
        input[type="password"] {
            width: calc(100% - 40px);
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 25px;
            border: 1px solid #ccc;
            box-sizing: border-box;
            font-size: 18px;
            font-weight: 900;
            letter-spacing: 2px;
        }
        button {
            width: 100%;
            padding: 20px;
            background-color: #FF6666;
            color: #fff;
            border: none;
            cursor: pointer;
            border-radius: 25px;
            font-size: 18px;
            font-weight: 900;
            letter-spacing: 2px;
        }
        button:hover {
            background-color: #FF4444;
        }
        input[type="text"]::placeholder,
        input[type="password"]::placeholder {
            color: #999;
        }
        small {
            display: block;
            margin-top: 5px;
            font-size: 0.8em;
            color: #666;
            font-weight: 900;
            letter-spacing: 2px;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <header>
            <h1 class="montserrat">MyMesa</h1>
        </header>
        <h2>Login</h2>
        
        <?php
        if (!empty($message)) {
            echo "<p>$message</p>";
        }
        ?>

        <form id="login-form" action="#" method="POST">
            <div class="input-group">
                <label for="username">Nome:</label>
                <input type="text" id="username" name="username" placeholder="Digite o nome" required>
            </div>
            <div class="input-group">
                <label for="password">CPF:</label>
                <input type="password" id="password" name="password" placeholder="CPF (Opcional)">
            </div>
            <button type="submit">Entrar</button>
        </form>
    </div>
</body>
</html>
