<?php
session_start();
include 'conexao.php';

// Verifica se um pedido foi removido do carrinho
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['remove_from_cart'])) {
    $index = $_POST['index'];
    unset($_SESSION['pedidos'][$index]);
    $_SESSION['pedidos'] = array_values($_SESSION['pedidos']); // Reindexa o array
}

// Verifica se o pedido foi finalizado
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['finalizar_pedido'])) {
    if (isset($_SESSION['pedidos']) && count($_SESSION['pedidos']) > 0) {
        foreach ($_SESSION['pedidos'] as $pedido) {
            $stmt = $conn->prepare("INSERT INTO pedidos (nome_produto, preco_produto, quantidade) VALUES (?, ?, ?)");
            $stmt->bind_param("sdi", $pedido['nome_produto'], $pedido['preco_produto'], $pedido['quantidade']);
            $stmt->execute();
            $stmt->close();
        }
        unset($_SESSION['pedidos']);
        echo "Pedido finalizado com sucesso.";
    } else {
        echo "Nenhum item no carrinho.";
    }
}
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MyMesa - Carrinho</title>
    <link rel="stylesheet" href="/assets/CSS/cardapio.css">
</head>
<style>
/* Seu estilo aqui */
body {
    margin: 0;
    padding: 0;
    background-color: #f4f4f4;
    display: flex;
    flex-direction: column;
    align-items: center;
    font-family: "Montserrat", sans-serif;
    font-optical-sizing: auto;
    font-weight: 900;
    font-style: normal;
    letter-spacing: 2px;
}

.container {
    display: flex;
    flex-direction: column;
    align-items: center;
    width: 100%;
    padding: 20px;
}

.cart-item {
    background-color: #fff;
    padding: 20px;
    margin: 10px 0;
    width: 80%;
    border-radius: 10px;
    box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.1);
}

.cart-item p {
    font-size: 18px;
}

.buttons {
    display: flex;
    align-items: center;
}

.buttons button {
    margin: 0 5px;
    padding: 5px 10px;
    font-size: 16px;
    cursor: pointer;
}

.button {
    font-family: "Montserrat", sans-serif;
    font-optical-sizing: auto;
    font-weight: 900;
    font-style: normal;
    letter-spacing: 2px;
    width: 100%;
    padding: 10px 0;
    background-color: #2a9d8f;
    color: white;
    text-align: center;
    border: none;
    border-radius: 5px;
    margin-top: 20px;
    cursor: pointer;
    text-decoration: none;
}

.back-button {
    font-family: "Montserrat", sans-serif;
    font-optical-sizing: auto;
    font-weight: 900;
    font-style: normal;
    letter-spacing: 2px;
    padding: 10px 20px;
    background-color: #e63946;
    color: white;
    text-align: center;
    border: none;
    border-radius: 5px;
    margin-top: 20px;
    cursor: pointer;
    text-decoration: none;
}
</style>
<body>
    <div class="container">
        <h1>Itens no Carrinho</h1>
        <?php if (isset($_SESSION['pedidos']) && count($_SESSION['pedidos']) > 0): ?>
            <?php foreach ($_SESSION['pedidos'] as $index => $pedido): ?>
                <div class="cart-item">
                    <p><?php echo $pedido['nome_produto']; ?> - R$ <?php echo number_format($pedido['preco_produto'], 2, ',', '.'); ?> x <?php echo $pedido['quantidade']; ?></p>
                    <form method="POST" action="">
                        <input type="hidden" name="index" value="<?php echo $index; ?>">
                        <button type="submit" name="remove_from_cart">Remover</button>
                    </form>
                </div>
            <?php endforeach; ?>
            <form method="POST" action="">
                <button type="submit" name="finalizar_pedido" class="button">Finalizar Pedido</button>
            </form>
        <?php else: ?>
            <p>Nenhum item no carrinho.</p>
        <?php endif; ?>
        <a href="cardapio.php" class="back-button">Voltar ao Cardápio</a>
    </div>
</body>
</html>
