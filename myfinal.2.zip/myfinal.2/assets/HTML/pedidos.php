<?php
session_start();

if (!isset($_SESSION['pedido'])) {
    $_SESSION['pedido'] = [];
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['add'])) {
        $prato = $_POST['prato'];
        $preco = $_POST['preco'];
        $itemExistente = false;

        foreach ($_SESSION['pedido'] as &$item) {
            if ($item['prato'] == $prato) {
                $item['quantidade']++;
                $itemExistente = true;
                break;
            }
        }

        if (!$itemExistente) {
            $_SESSION['pedido'][] = ['prato' => $prato, 'preco' => $preco, 'quantidade' => 1];
        }
    } elseif (isset($_POST['remove'])) {
        $prato = $_POST['prato'];

        foreach ($_SESSION['pedido'] as $index => &$item) {
            if ($item['prato'] == $prato) {
                if ($item['quantidade'] > 1) {
                    $item['quantidade']--;
                } else {
                    array_splice($_SESSION['pedido'], $index, 1);
                }
                break;
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pedidos</title>
    <link rel="stylesheet" href="assets\CSS\pedidos.css">
</head>
<style>
    body {
    margin: 0;
    padding: 0;
    font-family: "Montserrat", sans-serif;
    font-optical-sizing: auto;
    font-weight: 900;
    font-style: normal;
    letter-spacing: 2px;
}

header, footer {
    background-color: #ff5b5b;
    color: #ffffff;
    padding: 20px;
    text-align: center; 
}

section {
    margin: 20px;
}

button {
    display: block;
    margin: 20px auto;
    padding: 10px 20px;
    background-color: #000000;
    color: #fff;
    border: none;
    cursor: pointer;
    font-family: "Montserrat", sans-serif;
    font-optical-sizing: auto;
    font-weight: 900;
    font-style: normal;
    letter-spacing: 2px;
}

button:hover {
    background-color: #555;
}

select {
    width: 100%;
    padding: 10px;
    margin-bottom: 20px;
}

</style>
<body>
    <header>
        <h1>Pedidos</h1>
    </header>
    <a href="cardapio.php">Cardápio</a>
    <section id="status-section">
        <h2>Status do Pedido</h2>
        <p id="status">Em andamento</p>
    </section>
    <section id="pedido-lista">
        <ul>
            <?php foreach ($_SESSION['pedido'] as $item): ?>
                <li>
                    <?= $item['prato'] ?> - R$ <?= $item['preco'] ?> x <?= $item['quantidade'] ?>
                    <form method="POST" style="display:inline;">
                        <input type="hidden" name="prato" value="<?= $item['prato'] ?>">
                        <button type="submit" name="remove">-</button>
                        <button type="submit" name="add" value="true">+</button>
                        <input type="hidden" name="preco" value="<?= $item['preco'] ?>">
                    </form>
                </li>
            <?php endforeach; ?>
        </ul>
    </section>
    <section id="forma-pagamento-section">
        <h2>Forma de Pagamento</h2>
        <select id="formaPagamento">
            <option value="pix">Pix</option>
            <option value="cartao">Cartão</option>
            <option value="dinheiro">Dinheiro</option>
        </select>
    </section>
    <button id="voltar" onclick="window.location.href='cardapio.php'">Voltar para Cardápio</button>
    <footer>
        <button id="avaliacao" onclick="alert('Por favor, avalie nosso serviço.')">Avaliação</button>
    </footer>
</body>
</html>
