<?php
session_start();
include 'conexao.php';

// Verifica se um pedido foi adicionado ao carrinho
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_to_cart'])) {
    $productName = $_POST['product_name'];
    $productPrice = $_POST['product_price'];
    $quantity = $_POST['quantity'];

    // Armazena o pedido na sessão
    $pedido = [
        'nome_produto' => $productName,
        'preco_produto' => $productPrice,
        'quantidade' => $quantity
    ];

    if (!isset($_SESSION['pedidos'])) {
        $_SESSION['pedidos'] = [];
    }

    $_SESSION['pedidos'][] = $pedido;
}

// Função para obter os produtos do cardápio
function getDishes($category) {
    $dishes = [
        'bebidas' => [
            ['Suco de Laranja', 5.99],
            ['Refrigerante', 8.00],
            ['Água', 3.50],
        ],
        'pizza' => [
            ['Calabresa', 30.00],
            ['Quatro Queijos', 35.00],
            ['Margherita', 25.00],
        ],
        'acompanhamentos' => [
            ['Batata Frita', 15.00],
            ['Arroz Branco', 10.00],
        ],
        'sobremesas' => [
            ['Torta de Limão', 12.00],
            ['Pudim de Leite', 10.00],
            ['Sorvete de Chocolate', 8.00],
        ],
    ];

    return $dishes[$category] ?? [];
}

// Verifica a categoria selecionada
$category = isset($_GET['category']) ? $_GET['category'] : 'bebidas';
$dishes = getDishes($category);
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MyMesa - Cardápio</title>
    <link rel="stylesheet" href="/assets/CSS/cardapio.css">
</head>
<style>
/* Seu estilo aqui */
body {
    margin: 0;
    padding: 0;
    background-color: #f4f4f4;
    display: flex;
    font-family: "Montserrat", sans-serif;
    font-optical-sizing: auto;
    font-weight: 900;
    font-style: normal;
    letter-spacing: 2px;
}

.container {
    display: flex;
    height: 100vh;
    width: 100%;
}

.sidebar {
    width: 25%;
    background-color: #fff;
    padding: 20px;
    box-shadow: 2px 0 5px rgba(0,0,0,0.1);
}

.sidebar-item {
    margin-bottom: 20px;
    cursor: pointer;
}

.sidebar-item img {
    width: 100%;
    border-radius: 10px;
}

.sidebar-item p {
    text-align: center;
    font-size: 18px;
    color: #333;
}

.main-content {
    width: 75%;
    background-color: #e63946;
    display: flex;
    justify-content: center;
    align-items: center;
    color: white;
    font-size: 3em;
}

.dishes {
    display: flex;
    flex-direction: column;
    align-items: center;
    margin-top: 20px;
    color: black;
}

.dish {
    background-color: #fff;
    padding: 20px;
    margin: 10px 0;
    width: 80%;
    border-radius: 10px;
    box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.1);
}

.dish p {
    font-size: 18px;
}

.buttons {
    display: flex;
    align-items: center;
}

.buttons button {
    margin: 0 5px;
    padding: 5px 10px;
    font-size: 16px;
    cursor: pointer;
}

.button {
    font-family: "Montserrat", sans-serif;
    font-opt
-ical-sizing: auto;
font-weight: 900;
font-style: normal;
letter-spacing: 2px;
width: 100%;
padding: 10px 0;
background-color: #2a9d8f;
color: white;
text-align: center;
border: none;
border-radius: 5px;
margin-top: 20px;
cursor: pointer;
text-decoration: none;
}

.brand {
max-width: 300px;
padding: 20px;
font-family: "Montserrat", sans-serif;
font-optical-sizing: auto;
font-weight: 900;
font-style: normal;
letter-spacing: 2px;
}
</style>

<body>
    <div class="container">
        <div class="sidebar">
            <div class="sidebar-item" onclick="window.location.href='?category=bebidas'">
                <img src="assets/HTML/img/bebidas.png" alt="Bebidas">
            </div>
            <div class="sidebar-item" onclick="window.location.href='?category=pizza'">
                <img src="assets/HTML/img/pizza.png" alt="Pizza">
            </div>
            <div class="sidebar-item" onclick="window.location.href='?category=acompanhamentos'">
                <img src="assets/HTML/img/acompanhamentos.png" alt="Acompanhamentos">
            </div>
            <div class="sidebar-item" onclick="window.location.href='?category=sobremesas'">
                <img src="assets/HTML/img/sobremesas.png" alt="Sobremesas">
            </div>
            <button class="button" onclick="window.location.href='carrinho.php'">Ver Carrinho</button>
        </div>
        <div class="main-content">
            <div class="brand">MyMesa</div>
            <div id="dishes" class="dishes">
                <?php foreach ($dishes as $dish): ?>
                    <div class="dish">
                        <p><?php echo $dish[0]; ?> - R$ <?php echo number_format($dish[1], 2, ',', '.'); ?></p>
                        <form method="POST" action="">
                            <input type="hidden" name="product_name" value="<?php echo $dish[0]; ?>">
                            <input type="hidden" name="product_price" value="<?php echo $dish[1]; ?>">
                            <input type="number" name="quantity" value="1" min="1" style="width: 50px;">
                            <button type="submit" name="add_to_cart">Adicionar ao Pedido</button>
                        </form>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</body>
</html>